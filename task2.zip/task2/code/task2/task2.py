from googlesearch import search

def get_youtube_links(query, num_results=5):
    try:
        # Search for YouTube links related to the query
        search_query = f"site:youtube.com {query}"
        
        # Get search results from Google
        results = search(search_query, num_results=num_results, lang="en")

        # Filter and return only YouTube links
        youtube_links = [link for link in results if "youtube.com" in link]
        return youtube_links
    except Exception as e:
        return [f"Error: {e}"]

# Take input from the user
query = input("Enter the search query (e.g., 'java tutorials'): ")

# Get YouTube links based on the query
youtube_links = get_youtube_links(query)

# Print the YouTube links
if youtube_links:
    print("\nYouTube Links:")
    for link in youtube_links:
        print(link)
else:
    print("No YouTube links found for the given query.")
